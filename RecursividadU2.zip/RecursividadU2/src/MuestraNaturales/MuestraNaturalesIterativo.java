package MuestraNaturales;
import java.util.*;
public class MuestraNaturalesIterativo {
	public static void main(String[]args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Introduce n: ");
		int n = scanner.nextInt();
		muestraNaturalesIterativo(n);
		
	}
	
	public static void muestraNaturalesIterativo(int n) {
		for(int i=0;i<n;i++) {
			System.out.println(i+" ");
		}
	}
 

}
