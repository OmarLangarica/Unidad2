package Factorial;

import java.util.Scanner;

public class FactorialRecursivo {
    public static void main(String[] args) {
         Scanner leer = new Scanner(System.in);
        System.out.println("Proporcioname un numero");
        int n = leer.nextInt();
        long f = factorial(n);
        System.out.println("Factorial de "+n+"!: "+f);
        
    }
    
    public static long factorial(int n){
        if(n==0){
            return 1;
        }else{
            return factorial(n-1)*n;
        }
    }
}
