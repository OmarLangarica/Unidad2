package MuestraNaturales;

import java.util.Scanner;

public class MuestraNaturalesRecursivo {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Introduce n: ");
		int n = scanner.nextInt();
		muestraNaturalesRecursivo(n);
		

	}
	
	public static void muestraNaturalesRecursivo(int n) {
		System.out.print(n+" ");
		if(n>0) {
			muestraNaturalesRecursivo(n-1);
			//System.out.print(n+" ");
		}		
	}

}
